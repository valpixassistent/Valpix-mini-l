(()=>{
 if(window.valpixUnified)return;
 const panel=document.getElementById('valpixPanel');
 const previous=window.valpixDevicePhrase;
 if(!panel||!previous)return;
 window.valpixUnified=true;
 const go=(target,q='')=>{location.href='valpix-mode://'+target+'?q='+encodeURIComponent(q);};
 const clean=p=>p.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
   .replace(/[^\p{L}\p{N}\s]/gu,' ').trim().replace(/\s+/g,' ')
   .replace(/^(?:(?:ola )?(?:valpix|val pix|val peixe|volpix) )/,'')
   .replace(/^(?:por favor |podes |consegues |vamos )+/,'').replace(/ por favor$/,'');
 window.valpixDevicePhrase=async phrase=>{
   const t=clean(phrase);
   if(/^(?:abre|abrir|abra|vai para) (?:o |ao )?google$/.test(t)){go('google');return true;}
   if(/^(?:abre|abrir|usa|usar) (?:o )?telemovel$/.test(t)){go('home');return true;}
   const m=/^(?:pesquisa|pesquisar|procura|procurar) (?:no google )?(?:por )?(.+)$/.exec(t);
   if(m){go('google',m[1]);return true;}
   return previous(phrase);
 };
 panel.addEventListener('click',e=>{
   if(e.target.closest('[data-device="google"]')){e.preventDefault();e.stopImmediatePropagation();go('google');}
 },true);
 const b=document.createElement('button');b.textContent='Acesso ao ecrã';b.onclick=()=>go('access');panel.appendChild(b);
})();
