package pt.valpix.mini;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import org.json.JSONObject;

/** Both sizes of the face use the same authenticated local conversation server. */
final class Conversation {
    final Context context;
    final Handler main=new Handler(Looper.getMainLooper());
    final ExecutorService worker=Executors.newSingleThreadExecutor();
    MediaPlayer player;
    volatile boolean closed;
    boolean busy;
    String token="";
    Conversation(Context c){context=c;}
    byte[] post(String path,JSONObject data,String credential,int max) throws Exception {
        HttpURLConnection conn=(HttpURLConnection)new URL("http://127.0.0.1:8766/"+path).openConnection();
        conn.setConnectTimeout(4000);conn.setReadTimeout(75000);conn.setInstanceFollowRedirects(false);
        conn.setRequestMethod("POST");conn.setDoOutput(true);
        conn.setRequestProperty("Authorization","Bearer "+credential);
        conn.setRequestProperty("Content-Type","application/json");
        try{
            try(OutputStream out=conn.getOutputStream()){out.write(data.toString().getBytes(StandardCharsets.UTF_8));}
            int code=conn.getResponseCode();
            if(code!=200)throw new IOException(path+" · HTTP "+code);
            try(InputStream in=conn.getInputStream();ByteArrayOutputStream buf=new ByteArrayOutputStream()){
                byte[] part=new byte[8192];int n;
                while((n=in.read(part))!=-1){if(closed||buf.size()+n>max)throw new IOException("Resposta interrompida");buf.write(part,0,n);}
                return buf.toByteArray();
            }
        }finally{conn.disconnect();}
    }
    void say(String phrase){
        if(closed||busy)return;
        if(token.isEmpty()){notice("No rosto grande, guarda o token local da VALPIX.");return;}
        busy=true;
        final String credential=token;
        worker.execute(()->{
            File file=null;
            try{
                byte[] turn=post("turn",new JSONObject().put("text",phrase).put("quick",true),credential,64000);
                String answer=new JSONObject(new String(turn,StandardCharsets.UTF_8)).getString("text");
                byte[] wav=post("speech",new JSONObject().put("text",answer).put("voice","marin").put("style","charmosa"),credential,12000000);
                file=File.createTempFile("resposta",".wav",context.getCacheDir());
                try(OutputStream out=new FileOutputStream(file)){out.write(wav);}
                File ready=file;main.post(()->play(ready));
            }catch(Exception e){
                if(file!=null)file.delete();
                main.post(()->{busy=false;if(!closed)notice("Conversa indisponível. Verifica o Termux. "+e.getMessage());});
            }
        });
    }
    void play(File file){
        if(closed){file.delete();return;}
        try{
            player=new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            player.setDataSource(file.toString());player.prepare();
            player.setOnCompletionListener(p->finish());
            player.setOnErrorListener((p,a,b)->{finish();notice("A reprodução falhou.");return true;});
            player.start();
        }catch(Exception e){finish();notice("A reprodução falhou.");}
        finally{file.delete();}
    }
    void notice(String s){Toast.makeText(context,s,Toast.LENGTH_LONG).show();}
    void finish(){if(player!=null){player.release();player=null;}busy=false;}
    void close(){closed=true;token="";finish();worker.shutdownNow();}
}
