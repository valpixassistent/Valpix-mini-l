package pt.valpix.mini;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.*;
import android.widget.*;
import java.util.*;
import org.json.JSONTokener;

public class Main extends Activity {
    static final String FACE="http://127.0.0.1:8766/";
    WebView face;
    PermissionRequest media;
    boolean inFront;
    Uri pending;
    boolean askedOverlay;
    String hook;
    static boolean local(Uri u){
        return u!=null && "http".equals(u.getScheme()) && "127.0.0.1".equals(u.getHost()) && u.getPort()==8766;
    }
    public void onCreate(Bundle state){
        super.onCreate(state);
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        stopService(new Intent(this,Mini.class));
        face=new WebView(this);setContentView(face);
        try(java.io.InputStream input=getAssets().open("unir.js");Scanner sc=new Scanner(input,"UTF-8")){
            hook=sc.useDelimiter("\\A").next();
        }catch(Exception e){throw new IllegalStateException(e);}
        WebSettings settings=face.getSettings();
        settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        face.setWebViewClient(new WebViewClient(){
            public void onPageFinished(WebView w,String url){
                if(FACE.equals(url))w.evaluateJavascript(hook,null);
            }
            public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){
                Uri u=r.getUrl();
                if(!r.isForMainFrame())return true;
                if("valpix-mode".equals(u.getScheme()) && FACE.equals(w.getUrl()) && inFront){
                    if(Arrays.asList("google","home","access").contains(u.getHost())){
                        if("access".equals(u.getHost()))startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                        else {pending=u;askedOverlay=false;handoff();}
                    }
                    return true;
                }
                if(FACE.equals(u.toString()))return false;
                if(("https".equals(u.getScheme())||"http".equals(u.getScheme()))&&r.hasGesture())open(new Intent(Intent.ACTION_VIEW,u));
                return true;
            }
            public void onReceivedError(WebView w,WebResourceRequest req,WebResourceError error){
                if(req.isForMainFrame() && local(req.getUrl()))new AlertDialog.Builder(Main.this)
                  .setMessage("Inicia a VALPIX no Termux e depois toca em Recarregar.")
                  .setPositiveButton("Recarregar",(d,i)->face.loadUrl(FACE)).show();
            }
        });
        face.setWebChromeClient(new WebChromeClient(){
            public void onPermissionRequest(PermissionRequest req){
                if(!local(req.getOrigin())||!inFront||media!=null){req.deny();return;}
                media=req;ArrayList<String> ask=new ArrayList<>();
                for(String r:req.getResources()){
                    String p=permission(r);
                    if(p!=null && checkSelfPermission(p)!=PackageManager.PERMISSION_GRANTED)ask.add(p);
                }
                if(ask.isEmpty())grantMedia();else requestPermissions(ask.toArray(new String[0]),11);
            }
            public void onPermissionRequestCanceled(PermissionRequest req){if(media==req)media=null;}
        });
        face.loadUrl(FACE);
    }
    static String permission(String r){
        if(PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r))return Manifest.permission.RECORD_AUDIO;
        if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r))return Manifest.permission.CAMERA;
        return null;
    }
    void grantMedia(){
        PermissionRequest r=media;media=null;if(r==null)return;
        ArrayList<String> allowed=new ArrayList<>();
        for(String k:r.getResources()){String p=permission(k);if(p!=null && checkSelfPermission(p)==0)allowed.add(k);}
        if(allowed.isEmpty())r.deny();else r.grant(allowed.toArray(new String[0]));
    }
    void handoff(){
        if(!inFront||pending==null)return;
        if(!Settings.canDrawOverlays(this)){
            if(askedOverlay){pending=null;return;}
            askedOverlay=true;
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));return;
        }
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=0){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},12);return;
        }
        Uri dest=pending;pending=null;
        face.evaluateJavascript("(function(){stopVoice();return localStorage.getItem('valpix_work_token')||''})()",value->{
            if(!inFront)return;
            String token="";
            try{Object v=new JSONTokener(value).nextValue();if(v instanceof String)token=(String)v;}catch(Exception ignored){}
            startForegroundService(new Intent(this,Mini.class).putExtra("local_token",token));
            Intent next;
            if("google".equals(dest.getHost())){
                String q=dest.getQueryParameter("q");
                Uri u=Uri.parse("https://www.google.com/");
                if(q!=null&&!q.isEmpty())u=u.buildUpon().appendPath("search").appendQueryParameter("q",q).build();
                next=new Intent(Intent.ACTION_VIEW,u);
            }else next=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            open(next);
        });
    }
    void open(Intent i){try{startActivity(i);}catch(ActivityNotFoundException e){Toast.makeText(this,"Aplicação indisponível.",1).show();}}
    public void onRequestPermissionsResult(int code,String[] p,int[] results){
        super.onRequestPermissionsResult(code,p,results);
        if(code==11)grantMedia();
        if(code==12 && (results.length==0||results[0]!=0))pending=null;
        if(code==12 && pending!=null)face.post(()->handoff());
    }
    protected void onResume(){super.onResume();inFront=true;stopService(new Intent(this,Mini.class));if(pending!=null && (askedOverlay || checkSelfPermission(Manifest.permission.RECORD_AUDIO)==0))handoff();}
    protected void onPause(){inFront=false;super.onPause();}
    protected void onDestroy(){if(face!=null)face.destroy();super.onDestroy();}
}
