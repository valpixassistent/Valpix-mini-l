package pt.valpix.mini;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.*;
import org.json.JSONObject;
import java.io.IOException;
import android.view.*;
import android.widget.Toast;
import java.util.*;
import java.text.Normalizer;
public class Mini extends Service implements RecognitionListener {
 final Conversation conversation=new Conversation(this);
 long followUntil;
 public int onStartCommand(Intent i,int flags,int id){
   if(i!=null && i.hasExtra("local_token"))conversation.token=i.getStringExtra("local_token");
   return START_NOT_STICKY;
 }
 WindowManager windows; View eyes; SpeechService speech; Model model; Recognizer decoder; boolean stopped;

 public IBinder onBind(Intent i){return null;}
 public void onCreate(){super.onCreate();
 NotificationManager manager=getSystemService(NotificationManager.class);
 manager.createNotificationChannel(new NotificationChannel("voz","Escuta VALPIX",NotificationManager.IMPORTANCE_LOW));
 PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,Main.class),PendingIntent.FLAG_IMMUTABLE);
 startForeground(1,new Notification.Builder(this,"voz").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("VALPIX Mini · microfone ativo").setContentText("Abrir para parar a escuta").setContentIntent(open).build());
 windows=getSystemService(WindowManager.class);
 try {eyes=new Eyes(this);} catch(IOException e){fail("Não consegui carregar os olhos.");return;}
 int w=Math.round(118*getResources().getDisplayMetrics().density);
 WindowManager.LayoutParams lp=new WindowManager.LayoutParams(w,Math.round(w*465f/1210),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
 lp.gravity=Gravity.BOTTOM|Gravity.RIGHT;lp.x=w/8;lp.y=w/4;
 eyes.setContentDescription("Voltar à VALPIX");eyes.setOnClickListener(v->back());
 try{windows.addView(eyes,lp);}catch(RuntimeException e){stopSelf();return;}
 StorageService.unpack(this,"model","voz-portuguesa",loaded->{
    if(stopped){loaded.close();return;}
    model=loaded;
    try {
      decoder=new Recognizer(model,16000f);
      speech=new SpeechService(decoder,16000f);
      if(!speech.startListening(this))fail("Não consegui iniciar a escuta.");
    } catch(IOException|RuntimeException e){fail("Microfone indisponível. Fecha a outra escuta e tenta de novo.");}
 },e->{if(!stopped)fail("Não consegui carregar o modelo de voz.");});
 }
 void fail(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();stopSelf();}
 void open(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(RuntimeException e){Toast.makeText(this,"Não consegui abrir a página",0).show();}}
 void back(){startActivity(new Intent(this,Main.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP));stopSelf();}
 public void onResult(String json){
   if(stopped)return;
   String heard;
   try{heard=new JSONObject(json).optString("text","");}catch(Exception e){return;}
   if(conversation.busy||heard.trim().isEmpty())return;
   String n=Control.norm(heard).replaceFirst("^(?:valpix|val pix|vale pix|val peixe|vale peixe)[ ,]+","")
     .replaceFirst("^vamos (?:a )?abrir ","abre ").replaceFirst("^abrir ","abre ");
   if(n.matches("(?:volta|voltar|regressa) (?:ao |aos |para o |para os )?(?:ecra|rosto|olhos|valpix)")){back();return;}
   if(n.matches("abre (?:o )?google")){open("https://www.google.com/");return;}
   java.util.regex.Matcher m=java.util.regex.Pattern.compile("^(?:pesquisa[r]?|procura[r]?)(?: no google)?(?: por)? +(.+)$").matcher(n);
   if(m.matches()){open("https://www.google.com/search?q="+Uri.encode(m.group(1)));return;}
   boolean addressed=!Control.norm(heard).equals(n) && Control.norm(heard).matches("^(?:valpix|val pix|vale pix|val peixe|vale peixe) .+");
   if((addressed||n.startsWith("abre ")||n.matches("(sobe|desce)( a pagina)?"))&&Control.command(this,n))return;
   if(n.matches("valpix|val pix|vale pix|val peixe|vale peixe")){followUntil=SystemClock.elapsedRealtime()+15000;return;}
   if(addressed||n.startsWith("pergunta ")||SystemClock.elapsedRealtime()<followUntil){
     followUntil=SystemClock.elapsedRealtime()+45000;
     conversation.say(n.replaceFirst("^pergunta ",""));
   }
 }
 public void onPartialResult(String json){}
 public void onFinalResult(String json){if(!stopped)onResult(json);}
 public void onError(Exception e){if(!stopped)fail("A escuta foi interrompida. Abre a Mini para retomar.");}
 public void onTimeout(){}
 public void onDestroy(){
   stopped=true;conversation.close();
   if(speech!=null){speech.stop();speech.shutdown();}
   if(decoder!=null)decoder.close();
   if(model!=null)model.close();
   if(eyes!=null&&eyes.isAttachedToWindow())windows.removeView(eyes);
   super.onDestroy();
 }
}
