from pathlib import Path
import sys, json, hashlib, shutil, tempfile
from zipfile import ZipFile
root=Path.home()/'VALPIX_1_9_2'
with ZipFile(sys.argv[0]) as z:
    changes={}
    for name, old in json.loads(z.read('base.json')).items():
        dest=root/name
        if not dest.is_file(): sys.exit('Falta a instalação anterior da VALPIX.')
        data=z.read('valpix/'+name)
        current=dest.read_bytes()
        if current==data: continue
        if hashlib.sha256(current).hexdigest() not in (old if isinstance(old,list) else [old]): sys.exit('Versão diferente em '+name+'. Instalação interrompida para preservar as alterações.')
        changes[dest]=data
    if changes:
        backup=Path(tempfile.mkdtemp(prefix='antes_unico_',dir=root))
        for dest in changes: shutil.copy2(dest,backup/dest.name)
        try:
            for dest,data in changes.items():
                with tempfile.NamedTemporaryFile(dir=root,delete=False) as f: f.write(data)
                Path(f.name).replace(dest)
        except BaseException:
            for dest in changes: shutil.copy2(backup/dest.name,dest)
            raise
        print('Cópia anterior guardada em',backup)
    print('VALPIX pronta. Inicia o servidor e recarrega o Chrome.')
