package pt.valpix.mini;

import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.View;
import java.io.InputStream;
import java.io.IOException;
import java.util.Random;

/** Render the same face frames through two eye apertures and two brow masks. */
final class Eyes extends View {
    private final Bitmap[] frames = new Bitmap[3];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path mask = new Path();
    private final Random random = new Random();
    private long blinkAt = SystemClock.uptimeMillis() + 2400;

    Eyes(Context context) throws IOException {
        super(context);
        String[] names = {"open","half","closed"};
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = 2;
        for (int i=0; i<names.length; i++) {
            try (InputStream in=context.getAssets().open("eyes/"+names[i]+".png")) {
                frames[i]=BitmapFactory.decodeStream(in,null,opts);
            }
            if(frames[i]==null) throw new IOException("Olhos indisponíveis");
        }
        Path left=new Path();
        left.moveTo(185,160);left.cubicTo(312,44,492,64,557,215);
        left.cubicTo(438,119,325,97,185,160);left.close();
        left.moveTo(177,247);left.cubicTo(340,181,571,192,637,486);
        left.cubicTo(470,562,210,516,177,247);left.close();
        mask.addPath(left);
        Matrix mirror=new Matrix();mirror.setScale(-1,1);mirror.postTranslate(1544,0);
        mask.addPath(left,mirror);
    }
    @Override protected void onDraw(Canvas c) {
        long now=SystemClock.uptimeMillis(), age=now-blinkAt;
        int index=age<0||age>170?0:age<48||age>105?1:2;
        if(age>170)blinkAt=now+2400+random.nextInt(4100);
        c.save();
        c.scale(getWidth()/1210f,getHeight()/465f);c.translate(-167,-69);
        c.clipPath(mask);
        c.drawBitmap(frames[index],null,new Rect(0,0,1536,691),paint);
        c.restore();
        postInvalidateDelayed(age>=0&&age<=170?32:Math.max(20,blinkAt-now));
    }
}
