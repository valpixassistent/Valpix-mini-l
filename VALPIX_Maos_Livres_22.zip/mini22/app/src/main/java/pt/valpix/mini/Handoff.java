package pt.valpix.mini;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

/** Only a one-use ticket issued by the authenticated local face starts a handoff. */
public class Handoff extends Activity {
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        String ticket=getIntent().getStringExtra("ticket");
        if(ticket==null && getIntent().getData()!=null)ticket=getIntent().getData().getLastPathSegment();
        if(ticket==null||!ticket.matches("[0-9a-f]{48}")){finish();return;}
        final String id=ticket;
        new Thread(()->{
            try{
                HttpURLConnection c=(HttpURLConnection)new URL("http://127.0.0.1:8766/mini-ticket/"+id).openConnection();
                c.setInstanceFollowRedirects(false);c.setConnectTimeout(3000);c.setReadTimeout(3000);
                c.setRequestMethod("POST");
                try(InputStream in=c.getInputStream()){
                    ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] block=new byte[512];int n;
                    while((n=in.read(block))!=-1&&buf.size()<4096)buf.write(block,0,n);
                    JSONObject data=new JSONObject(buf.toString("UTF-8"));
                    runOnUiThread(()->activate(data));
                }finally{c.disconnect();}
            }catch(Exception e){runOnUiThread(()->{Toast.makeText(this,"Pedido expirado. Repete o pedido na VALPIX.",1).show();finish();});}
        }).start();
    }
    private void activate(JSONObject data){
        if(isFinishing()||isDestroyed())return;
        if(!Settings.canDrawOverlays(this)||checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=0){
            startActivity(new Intent(this,Main.class));finish();return;
        }
        startForegroundService(new Intent(this,Mini.class));
        if("google".equals(data.optString("target"))){
            String query=data.optString("query","");
            Uri uri=Uri.parse(query.isEmpty()?"https://www.google.com/":"https://www.google.com/search?q="+Uri.encode(query));
            startActivity(new Intent(Intent.ACTION_VIEW,uri));
        }else startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME));
        finish();
    }
}
