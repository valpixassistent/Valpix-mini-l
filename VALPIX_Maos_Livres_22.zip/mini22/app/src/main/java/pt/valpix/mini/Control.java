package pt.valpix.mini;
import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.content.pm.*;
import android.graphics.Rect;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import java.util.*;
import java.text.Normalizer;

public class Control extends AccessibilityService {
 static Control instance;
 protected void onServiceConnected(){instance=this;}
 public void onDestroy(){instance=null;super.onDestroy();}
 public void onAccessibilityEvent(AccessibilityEvent e){}
 public void onInterrupt(){}
 static String norm(String s){return Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).trim();}
 static boolean command(Context c,String n){
  if(n.startsWith("abre ")&&!n.matches("abre (o )?google")){
   String name=n.substring(5).replaceFirst("^(?:a aplicacao |a app |o |a )","");
   Intent intent=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
   PackageManager pm=c.getPackageManager();
   List<ResolveInfo> matches=new ArrayList<>();
   for(ResolveInfo app:pm.queryIntentActivities(intent,0))if(norm(app.loadLabel(pm).toString()).equals(name))matches.add(app);
   if(matches.size()==1){ActivityInfo a=matches.get(0).activityInfo;
    try{c.startActivity(intent.setClassName(a.packageName,a.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}catch(RuntimeException e){notice(c,"Não consegui abrir essa aplicação.");}
   }else notice(c,"Preciso do nome exato de uma aplicação.");
   return true;
  }
  boolean read=n.matches("(le o ecra|o que esta no ecra)"), tap=n.startsWith("toca em "), scroll=n.matches("(sobe|desce)( a pagina)?");
  if(!read&&!tap&&!scroll)return false;
  if(instance==null){notice(c,"Ativa o acesso ao ecrã na VALPIX Mini.");return true;}
  instance.act(n,read,tap);return true;
 }
 static void notice(Context c,String s){Toast.makeText(c,s,Toast.LENGTH_LONG).show();}
 void act(String cmd,boolean read,boolean tap){
  AccessibilityNodeInfo root=getRootInActiveWindow();
  if(root==null){notice(this,"Este ecrã não disponibiliza conteúdo.");return;}
  ArrayDeque<AccessibilityNodeInfo> queue=new ArrayDeque<>();queue.add(root);
  AccessibilityNodeInfo target=null;Set<String> text=new LinkedHashSet<>();int count=0;
  while(!queue.isEmpty()&&count++<600){
   AccessibilityNodeInfo node=queue.remove();
   if(node.isPassword())continue;
   if(node.isVisibleToUser()){
    CharSequence label=node.getText()!=null?node.getText():node.getContentDescription();
    if(label!=null){String value=label.toString().trim();if(!value.isEmpty())text.add(value);
     if(tap&&norm(value).equals(cmd.substring(8))){
      AccessibilityNodeInfo item=node;while(item!=null&&!item.isClickable())item=item.getParent();
      if(item!=null){if(target!=null&&!target.equals(item)){notice(this,"Há dois itens com esse nome.");return;}target=item;}
     }}
    if(!read&&!tap&&target==null&&node.isScrollable())target=node;
   }
   for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo child=node.getChild(i);if(child!=null)queue.add(child);}
  }
  if(read){String result=android.text.TextUtils.join(" · ",text);notice(this,result.isEmpty()?"Sem texto acessível.":result.substring(0,Math.min(180,result.length())));return;}
  if(target==null){notice(this,"Não encontrei esse controlo.");return;}
  Rect box=new Rect();target.getBoundsInScreen(box);
  int action=tap?AccessibilityNodeInfo.ACTION_CLICK:cmd.startsWith("desce")?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD;
  if(target.performAction(action))dot(box);else notice(this,"A aplicação recusou o gesto.");
 }
 void dot(Rect r){
  WindowManager wm=getSystemService(WindowManager.class);View v=new View(this);
  GradientDrawable d=new GradientDrawable();d.setShape(GradientDrawable.OVAL);d.setColor(0xbb00cfff);v.setBackground(d);
  WindowManager.LayoutParams p=new WindowManager.LayoutParams(30,30,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
  p.gravity=Gravity.TOP|Gravity.LEFT;p.x=r.centerX()-15;p.y=r.centerY()-15;
  wm.addView(v,p);new Handler(getMainLooper()).postDelayed(()->{if(v.isAttachedToWindow())wm.removeView(v);},550);
 }
}
