package pt.valpix.mini;
import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.provider.Settings;
import android.net.Uri;
import android.widget.*;
public class Main extends Activity {
 public void onCreate(Bundle b){super.onCreate(b);setTitle("VALPIX Mini");
 LinearLayout box=new LinearLayout(this);box.setOrientation(1);setContentView(box);
 Button access=new Button(this);access.setText("Ativar acesso ao ecrã");box.addView(access);
 access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
 Button start=new Button(this);start.setText("Ativar olhos e escuta");box.addView(start);
 start.setOnClickListener(v->{
 if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));return;}
 if(checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=0){requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},1);return;}
 startForegroundService(new Intent(this,Mini.class));moveTaskToBack(true);});
 Button stop=new Button(this);stop.setText("Parar olhos e escuta");box.addView(stop);stop.setOnClickListener(v->stopService(new Intent(this,Mini.class)));
 }}
